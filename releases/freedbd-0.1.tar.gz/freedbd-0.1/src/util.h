#ifndef __UTIL_H__
#define __UTIL_H__

void VPRINTF(int level, char* arg, ...);

extern int gVerbosity;

#endif /* __SERVER_H__ */

/* vim:set ts=2 sw=2: */
